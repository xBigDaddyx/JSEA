﻿using Junior_School_Evaluation_Application.Classes.Models;
using Junior_School_Evaluation_Application.Classes.Services;
using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Junior_School_Evaluation_Application.Classes.Services
{
    public partial class ClassesList : Form
    {
        private ClassesService services;

        private ClassesDTO selectedClasses;

        public ClassesList()
        {
            InitializeComponent();
            services = new ClassesService();
            selectedClasses = new ClassesDTO();

            btn_update.Visible = false;
            btn_delete.Visible = false;
        }
         
        private void ClassesListInterfaces_Load(object sender, EventArgs e)
        {
            services.bindData(dgrid_list_student);
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            services.addNewClasses(dgrid_list_student);
        }

        private void dgrid_list_student_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow currentRow = dgrid_list_student.CurrentRow;
            selectedClasses.id = currentRow.Cells[0].Value.ToString();
            selectedClasses.name = currentRow.Cells[1].Value.ToString();

            btn_update.Visible = true;
            btn_delete.Visible = true;

            lbl_selected.Text = selectedClasses.name;
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            services.editClasses(dgrid_list_student, selectedClasses);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            services.deleteClasses(dgrid_list_student, selectedClasses);
        }
    }
}
