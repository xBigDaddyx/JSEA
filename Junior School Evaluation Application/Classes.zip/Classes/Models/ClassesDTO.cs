﻿namespace Junior_School_Evaluation_Application.Classes.Models
{
    public class ClassesDTO
    {
        public string id { get; set; }
        public string name { get; set; }
        public string capacity { get; set; }
    }
}
